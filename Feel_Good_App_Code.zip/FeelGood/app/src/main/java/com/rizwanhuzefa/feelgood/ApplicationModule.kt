package com.rizwanhuzefa.feelgood

import android.app.Application
import android.content.Context
import com.rizwanhuzefa.feelgood.roomdb.ItemListDao
import com.rizwanhuzefa.feelgood.roomdb.db

class ApplicationModule : Application() {

    companion object {
        @Volatile
        lateinit var context: ApplicationModule

        lateinit var listDao: ItemListDao
    }

    override fun onCreate() {
        super.onCreate()
        context = this
        listDao = db.userDao()
    }
}