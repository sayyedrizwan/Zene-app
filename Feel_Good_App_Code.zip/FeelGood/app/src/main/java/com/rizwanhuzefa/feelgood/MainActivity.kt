package com.rizwanhuzefa.feelgood

import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.rizwanhuzefa.feelgood.roomdb.ItemsListEntity
import com.rizwanhuzefa.feelgood.service.NOTIFICATION_CLICK
import com.rizwanhuzefa.feelgood.service.NOTIFICATION_IMG
import com.rizwanhuzefa.feelgood.service.NOTIFICATION_TEXT
import com.rizwanhuzefa.feelgood.ui.theme.FeelGoodTheme
import com.rizwanhuzefa.feelgood.utils.SharedPrefsManager.doShowCard
import com.rizwanhuzefa.feelgood.utils.Utils
import com.rizwanhuzefa.feelgood.utils.Utils.NOTIFICATION_CLICKED_EVENTS
import com.rizwanhuzefa.feelgood.utils.Utils.events
import com.rizwanhuzefa.feelgood.utils.Utils.redirectToNotificationPermissions
import com.rizwanhuzefa.feelgood.utils.Utils.toast
import com.rizwanhuzefa.feelgood.view.FirstPageView
import com.rizwanhuzefa.feelgood.view.HomeLists


class MainActivity : ComponentActivity() {

    private val homeViewModel: HomeViewModel by viewModels()

    private lateinit var requestPermissionLauncher: ActivityResultLauncher<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val extra = intent.extras
        extra?.keySet()?.forEach {
            if (it == NOTIFICATION_CLICK) {
                events(NOTIFICATION_CLICKED_EVENTS)

//                val item = ItemsListEntity(
//                    null, extra.getString(NOTIFICATION_TEXT) ?: "", 0,extra.getString(NOTIFICATION_IMG) ?: ""
//                )
//                homeViewModel.showInfo(item)
            }
        }

        setContent {
            FeelGoodTheme {
                var showSplash by remember { mutableStateOf(false) }

                HomeLists(homeViewModel) {
                    showSplash = true
                }

                if (showSplash) FirstPageView {
                    showSplash = false
                }

                LaunchedEffect(Unit) {
                    if (doShowCard) showSplash = true
                }
            }
        }

        requestPermissionLauncher =
            registerForActivityResult(ActivityResultContracts.RequestPermission()) {
                if (it)
                    Utils.updateFCM()
                else
                    redirectToNotificationPermissions()

            }
    }

    override fun onStart() {
        super.onStart()
        Utils.updateFCM()
        homeViewModel.getPagination()
        askNotificationPermission()
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_DENIED
            ) {
                val adb = AlertDialog.Builder(this).apply {
                    setTitle(resources.getString(R.string.notification_permission))
                    setMessage(resources.getString(R.string.notification_permission_desc))

                }
                adb.setPositiveButton(resources.getString(R.string.grant)) { dialog, _ ->
                    requestPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                    dialog.dismiss()
                }
                adb.setNegativeButton(resources.getString(R.string.cancel)) { dialog, _ ->
                    dialog.dismiss()
                }
                adb.show()
            }
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)

        val extra = intent?.extras
        extra?.keySet()?.forEach {
            if (it == NOTIFICATION_CLICK) {
                events(NOTIFICATION_CLICKED_EVENTS)

//                val item = ItemsListEntity(
//                    null, extra.getString(NOTIFICATION_TEXT) ?: "", 0,extra.getString(NOTIFICATION_IMG) ?: ""
//                )
//                homeViewModel.showInfo(item)
            }
        }
    }
}