package com.rizwanhuzefa.feelgood.view

import android.app.Activity
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.rizwanhuzefa.feelgood.ApplicationModule.Companion.context
import com.rizwanhuzefa.feelgood.ApplicationModule.Companion.listDao
import com.rizwanhuzefa.feelgood.R
import com.rizwanhuzefa.feelgood.roomdb.ItemsListEntity
import com.rizwanhuzefa.feelgood.service.generateNotification
import com.rizwanhuzefa.feelgood.ui.theme.BlueColor
import com.rizwanhuzefa.feelgood.utils.SharedPrefsManager.doShowCard
import com.rizwanhuzefa.feelgood.utils.Utils.setImageDownload
import com.rizwanhuzefa.feelgood.utils.Utils.toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


@Composable
fun FirstPageView(close: () -> Unit) {

    val activity = LocalContext.current as Activity

    var paint by remember { mutableStateOf(R.drawable.first_card_view) }

    val willReceiveNotification = stringResource(id = R.string.will_start_notification)

    Box(
        Modifier
            .fillMaxSize()
            .background(BlueColor)
    ) {
        Image(
            painterResource(id = R.drawable.feel_good_text),
            "",
            Modifier
                .size(180.dp)
                .align(Alignment.TopStart)
                .padding(5.dp)
                .offset(x = 0.dp, y = (-40).dp),
            contentScale = ContentScale.Fit
        )


        Image(
            painterResource(id = R.drawable.feel_good_chicken),
            "",
            Modifier
                .align(Alignment.Center)
                .fillMaxWidth()
                .height(LocalConfiguration.current.screenHeightDp.dp / 2)
                .offset(x = 0.dp, y = (-90).dp),
            contentScale = ContentScale.Fit
        )


        Image(
            painterResource(paint), "",
            Modifier
                .align(Alignment.BottomCenter)
                .padding(5.dp)
                .height((LocalConfiguration.current.screenHeightDp / 2.2).dp)
                .width(LocalConfiguration.current.screenWidthDp.dp),
            contentScale = ContentScale.Fit
        )

        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .height((LocalConfiguration.current.screenHeightDp / 2.2).dp)
        ) {
            Spacer(
                Modifier
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable {
                        when (paint) {
                            R.drawable.first_card_view -> {}
                            R.drawable.second_card_view -> paint = R.drawable.first_card_view
                            R.drawable.third_card_view -> paint = R.drawable.second_card_view
                            R.drawable.fourth_card_view -> paint = R.drawable.third_card_view
                        }
                    })
            Spacer(
                Modifier
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable {
                        when (paint) {
                            R.drawable.first_card_view -> paint = R.drawable.second_card_view
                            R.drawable.second_card_view -> paint = R.drawable.third_card_view
                            R.drawable.third_card_view -> paint = R.drawable.fourth_card_view
                            R.drawable.fourth_card_view -> {
                                CoroutineScope(Dispatchers.IO).launch {
                                    if (listDao.getLatestTen().isEmpty()) {
                                        val icon = BitmapFactory.decodeResource(
                                            context.resources,
                                            R.drawable.feel_img
                                        )
                                        val item = ItemsListEntity(
                                            null,
                                            "Feels is now your Buddy ❤️",
                                            System.currentTimeMillis(),
                                            setImageDownload(icon)
                                        )
                                        listDao.insert(item)

                                        generateNotification(item, icon)
                                    }
                                    doShowCard = false
                                    close()
                                    activity.finishAffinity()
                                    willReceiveNotification.toast()
                                }
                            }
                        }
                    })
        }

    }
}
