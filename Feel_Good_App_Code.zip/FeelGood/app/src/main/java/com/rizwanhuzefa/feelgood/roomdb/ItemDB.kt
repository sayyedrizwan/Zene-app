package com.rizwanhuzefa.feelgood.roomdb

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.rizwanhuzefa.feelgood.ApplicationModule
import com.rizwanhuzefa.feelgood.utils.Utils

@Database(entities = [ItemsListEntity::class], version = 1)
abstract class ItemDB : RoomDatabase() {
    abstract fun userDao(): ItemListDao
}


val db = Room.databaseBuilder(ApplicationModule.context, ItemDB::class.java, Utils.DB_NAME).build()
