package com.rizwanhuzefa.feelgood

import android.util.Log
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rizwanhuzefa.feelgood.ApplicationModule.Companion.listDao
import com.rizwanhuzefa.feelgood.roomdb.ItemsListEntity
import com.rizwanhuzefa.feelgood.ui.theme.CardColorOne
import com.rizwanhuzefa.feelgood.ui.theme.CardColorThree
import com.rizwanhuzefa.feelgood.ui.theme.CardColorTwo
import com.rizwanhuzefa.feelgood.utils.Utils.colorList
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class HomeViewModel : ViewModel() {


    val list = mutableStateListOf<ItemsListEntity>()
    var doShowLoadBtn = mutableStateOf(true)
        private set
    var hideBackCard = mutableStateOf(true)
        private set

    var showInfo = mutableStateOf<ItemsListEntity?>(null)
        private set

    var colorOne = mutableStateOf(CardColorOne)
        private set

    var colorTwo = mutableStateOf(CardColorTwo)
        private set

    var colorThree = mutableStateOf(CardColorThree)
        private set

    var colorFour = mutableStateOf(Color.White)
        private set

    var isLast = mutableStateOf(false)
        private set

    var isFirst = mutableStateOf(true)
        private set

    var currentNumber = mutableStateOf(-1)
        private set


    init {
        list.clear()
    }

    fun getPagination() = viewModelScope.launch(Dispatchers.IO) {
        list.clear()
        currentNumber.value = -1
        doShowLoadBtn.value = false
        val l = listDao.getAll(list.size)
        doShowLoadBtn.value = l.size >= 500

        for (item in l) {
            list.add(item)
        }

        runItems(true)
    }

    fun runItems(next: Boolean) {
        try {
            if (next)
                currentNumber.value += 1
            else
                currentNumber.value -= 1

            if (!next) {
                isLast.value = false
            }

            showInfo.value = list[currentNumber.value]

            if (list.size == 1) {
                hideBackCard.value = true
                isLast.value = true
                isFirst.value = true
            }

            if (list.size - 1 == currentNumber.value) {
                isLast.value = true
                hideBackCard.value = true
            }

//            if (list.size > 0 && currentNumber.value == -1){
//                isLast.value = false
//                hideBackCard.value = false
//            }


            isFirst.value = currentNumber.value == 0


            if (currentNumber.value > 0) {
                colorOne.value = colorTwo.value
                colorTwo.value = colorThree.value
                colorThree.value = colorFour.value
                colorFour.value = colorOne.value
            }
        } catch (e: Exception) {
            e.message
        }
    }


    fun showInfo(item: ItemsListEntity?) = viewModelScope.launch(Dispatchers.IO) {
        showInfo.value = item
    }


}

