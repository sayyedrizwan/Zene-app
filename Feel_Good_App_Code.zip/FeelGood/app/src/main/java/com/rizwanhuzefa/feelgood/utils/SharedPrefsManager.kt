package com.rizwanhuzefa.feelgood.utils

import android.content.Context
import com.rizwanhuzefa.feelgood.ApplicationModule.Companion.context


object SharedPrefsManager {

    private val s = context.getSharedPreferences("db", Context.MODE_PRIVATE)


    var doShowCard
        get() = s.getBoolean("isShowedSplash", true)
        set(value) = s.edit().putBoolean("isShowedSplash", value).apply()
}