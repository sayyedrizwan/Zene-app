package com.rizwanhuzefa.feelgood.service


import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import coil.ImageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.rizwanhuzefa.feelgood.ApplicationModule.Companion.context
import com.rizwanhuzefa.feelgood.ApplicationModule.Companion.listDao
import com.rizwanhuzefa.feelgood.MainActivity
import com.rizwanhuzefa.feelgood.R
import com.rizwanhuzefa.feelgood.roomdb.ItemsListEntity
import com.rizwanhuzefa.feelgood.utils.Utils.NOTIFICATION_RECEIVED_EVENTS
import com.rizwanhuzefa.feelgood.utils.Utils.events
import com.rizwanhuzefa.feelgood.utils.Utils.setImageDownload
import com.rizwanhuzefa.feelgood.utils.Utils.updateFCM
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.InternalCoroutinesApi
import kotlinx.coroutines.launch

@OptIn(InternalCoroutinesApi::class)
class FirebaseMessageService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        updateFCM()
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        message.data.let {
            val data = message.data

            val title = data["title"] ?: ""
            val img = data["img"] ?: ""


            CoroutineScope(Dispatchers.IO).launch {
                if (img.isEmpty()) return@launch
                if (title.isEmpty()) return@launch

                try {

                    val loader = ImageLoader(context)
                    val request = ImageRequest.Builder(context)
                        .data(img)
                        .allowHardware(false)
                        .build()

                    val result = (loader.execute(request) as SuccessResult).drawable
                    val bitmap = (result as BitmapDrawable).bitmap

                    events(NOTIFICATION_RECEIVED_EVENTS)

                    val item = ItemsListEntity(
                        null, title, System.currentTimeMillis(), setImageDownload(bitmap)
                    )
                    listDao.insert(item)
                    generateNotification(item, bitmap)
                } catch (e: Exception) {
                    e.message
                }
            }
        }
    }
}


const val NOTIFICATION_CLICK = "notification_click"
const val NOTIFICATION_TEXT = "notification_text"
const val NOTIFICATION_IMG = "notification_img"

@SuppressLint("MissingPermission")
fun generateNotification(items: ItemsListEntity, bitmap: Bitmap) {
    try {
        val channelId = "feel_good_channel"
        val channelName = "Feel Good Quotes"
        val channelDescription = "Enable to send Feel Good app Quotes"

        val soundUri = Uri.parse(
            "android.resource://" + context.packageName + "/" + R.raw.notification_tone
        )
        val v = longArrayOf(0, 100, 200, 300)

        val audioAttributes = AudioAttributes.Builder()
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .setUsage(AudioAttributes.USAGE_ALARM)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(channelId, channelName, importance).apply {
                description = channelDescription
            }
            val notificationManager: NotificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            channel.setSound(soundUri, audioAttributes)
            channel.vibrationPattern = v
            notificationManager.createNotificationChannel(channel)
        }
        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentText(items.text).setPriority(NotificationCompat.PRIORITY_HIGH)
            .setLargeIcon(bitmap)
            .setStyle(NotificationCompat.BigPictureStyle().bigPicture(bitmap))
            .setStyle(NotificationCompat.BigTextStyle().bigText(items.text))
            .setSound(soundUri).setVibrate(v)

        val intent = Intent(context, MainActivity::class.java)
        intent.putExtra(NOTIFICATION_CLICK, "not")
        intent.putExtra(NOTIFICATION_TEXT, items.text)
        intent.putExtra(NOTIFICATION_IMG, items.imagePath)

        val pendingIntent = PendingIntent.getActivity(
            context, 0, intent, PendingIntent.FLAG_MUTABLE
        )
        builder.setContentIntent(pendingIntent)

        val notificationId = (12..999).random()
        val notificationManagers = NotificationManagerCompat.from(context)
        notificationManagers.notify(notificationId, builder.build())

    } catch (e: Exception) {
        e.message
    }
}