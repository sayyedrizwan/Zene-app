package com.rizwanhuzefa.feelgood.utils

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Bitmap.CompressFormat
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore.Images
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.analytics.ktx.analytics
import com.google.firebase.ktx.Firebase
import com.google.firebase.messaging.ktx.messaging
import com.rizwanhuzefa.feelgood.ApplicationModule.Companion.context
import com.rizwanhuzefa.feelgood.ui.theme.CardColorOne
import com.rizwanhuzefa.feelgood.ui.theme.CardColorThree
import com.rizwanhuzefa.feelgood.ui.theme.CardColorTwo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import kotlin.random.Random


object Utils {

    const val DB_NAME = "item_list"


    private const val FCM_ALL_TOPIC = "all"


    fun updateFCM() {
        Firebase.messaging.subscribeToTopic(FCM_ALL_TOPIC)
            .addOnCompleteListener {}.addOnFailureListener { }
    }

    fun redirectToNotificationPermissions() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        val uri = Uri.fromParts("package", context.packageName, null)
        intent.data = uri
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(intent)
    }

    fun Any.toast() = CoroutineScope(Dispatchers.Main).launch {
        Toast.makeText(context, this@toast.toString(), Toast.LENGTH_LONG).show()
    }

    private fun generateRandomNameAndNumber(): String {
        val name = generateRandomString(10)
        val number = generateRandomNumber(1000, 9999)

        return "${System.currentTimeMillis()}$name$number"
    }

    private fun generateRandomString(length: Int): String {
        val charPool: List<Char> = ('a'..'z') + ('A'..'Z')
        return (1..length)
            .map { charPool.random() }
            .joinToString("")
    }

    private fun generateRandomNumber(min: Int, max: Int): Int {
        require(min <= max) { "Invalid range" }
        return Random.nextInt(min, max + 1)
    }

    fun setImageDownload(b: Bitmap): String {
        val fileMain = File(context.filesDir, "imgpath").apply { mkdirs() }
        val file = File(fileMain, "${generateRandomNameAndNumber()}.png")
        val fos = FileOutputStream(file)

        fos.use {
            b.compress(CompressFormat.PNG, 1, it)
        }

        return file.absolutePath
    }

    private val firebaseAnalytics: FirebaseAnalytics by lazy {
        Firebase.analytics
    }


    const val NOTIFICATION_RECEIVED_EVENTS = "notification_received"
    const val NOTIFICATION_CLICKED_EVENTS = "notification_clicked"

    fun events(e: String) {
        val b = Bundle()
        firebaseAnalytics.logEvent(e, b)
    }


    fun shareText(textV: String, imagePath: File) {
        val myBitmap = BitmapFactory.decodeFile(imagePath.absolutePath)
        val bitmapPath: String =
            Images.Media.insertImage(context.contentResolver, myBitmap, "feel_good_img", null)

        val bitmapUri = Uri.parse(bitmapPath)

        val text = """
            $textV 
            
            Do you want to receive feels like me? Have it here: https://play.google.com/store/apps/details?id=${context.packageName}
        """.trimIndent()

        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "image/png"
        intent.putExtra(Intent.EXTRA_TEXT, text)
        intent.putExtra(Intent.EXTRA_STREAM, bitmapUri)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(intent)


//        val intent = Intent(Intent.ACTION_SEND)
//        intent.putExtra(Intent.EXTRA_TEXT, text)
//        intent.type = "text/plain"
//        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
//        context.startActivity(intent)
    }

    val colorList = listOf(
        CardColorOne, CardColorTwo, CardColorThree
    )
}