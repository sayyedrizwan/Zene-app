package com.rizwanhuzefa.feelgood.view

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.rizwanhuzefa.feelgood.HomeViewModel
import com.rizwanhuzefa.feelgood.R
import com.rizwanhuzefa.feelgood.roomdb.ItemsListEntity
import com.rizwanhuzefa.feelgood.ui.theme.BlueColor
import com.rizwanhuzefa.feelgood.ui.theme.caveatFamily
import com.rizwanhuzefa.feelgood.ui.theme.juliusFamily
import com.rizwanhuzefa.feelgood.utils.Utils.redirectToNotificationPermissions
import com.rizwanhuzefa.feelgood.utils.Utils.shareText
import com.rizwanhuzefa.feelgood.utils.Utils.toast
import java.io.File


@Composable
fun HomeLists(home: HomeViewModel, showSplash: () -> Unit) {

    val needPermission = stringResource(id = R.string.need_storage_permission)

    val storagePermission =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
            if (it) {
                shareText(
                    home.showInfo.value?.text ?: "",
                    File(home.showInfo.value?.imagePath ?: "")
                )
            } else {
                needPermission.toast()
                redirectToNotificationPermissions()
            }
        }

    Box(
        Modifier
            .fillMaxSize()
            .background(BlueColor)
    ) {
        Column(
            Modifier
                .align(Alignment.TopStart)
        ) {
            Image(
                painterResource(id = R.drawable.feel_good_text),
                "",
                Modifier
                    .size(180.dp)
                    .padding(5.dp)
                    .offset(x = 0.dp, y = (-60).dp),
                contentScale = ContentScale.Fit
            )

//            Text(
//                if (home.list.isNotEmpty()) stringResource(id = R.string.your_feels) else
//                    stringResource(id = R.string.no_your_feels),
//                Modifier
//                    .fillMaxWidth()
//                    .offset(x = 0.dp, y = (-110).dp),
//                fontFamily = caveatFamily,
//                textAlign = TextAlign.Center,
//                color = Color.White,
//                fontSize = 35.sp
//            )
        }

        if (home.list.isNotEmpty()) {
            AsyncImage(
                File(home.showInfo.value?.imagePath ?: ""),
                "",
                Modifier
                    .align(Alignment.Center)
                    .offset(x = 0.dp, y = (-110).dp)
                    .fillMaxWidth()
                    .height((LocalConfiguration.current.screenHeightDp / 2.4).dp),
                contentScale = ContentScale.Crop
            )

            Box(
                Modifier
                    .align(Alignment.BottomCenter)
            ) {

//                if (!home.isLast.value) {
//                    Column(
//                        Modifier
//                            .align(Alignment.BottomCenter)
//                            .offset(x = 20.dp, y = (-61).dp)
//                            .rotate(22f)
//                            .width((LocalConfiguration.current.screenWidthDp / 2.1).dp)
//                            .height((LocalConfiguration.current.screenWidthDp / 1.5).dp)
//                            .clip(RoundedCornerShape(13.dp))
//                            .background(home.colorThree.value)
//                            .verticalScroll(rememberScrollState())
//
//                    ) {}
//
//                    Column(
//                        Modifier
//                            .align(Alignment.BottomCenter)
//                            .offset(x = 20.dp, y = (-65).dp)
//                            .rotate(10f)
//                            .width((LocalConfiguration.current.screenWidthDp / 2.1).dp)
//                            .height((LocalConfiguration.current.screenWidthDp / 1.5).dp)
//                            .clip(RoundedCornerShape(13.dp))
//                            .background(home.colorTwo.value)
//                            .verticalScroll(rememberScrollState())
//
//                    ) {}
//                }
                Column(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .offset(x = 20.dp, y = (-65).dp)
                        .rotate(-10f)
                        .width((LocalConfiguration.current.screenWidthDp / 2.1).dp)
                        .height((LocalConfiguration.current.screenWidthDp / 1.5).dp)
                        .clip(RoundedCornerShape(13.dp))
                        .background(Color.White)
//                        .background(home.colorOne.value)
                        .verticalScroll(rememberScrollState()),
                    Arrangement.Center, Alignment.CenterHorizontally
                ) {
                    Text(
                        home.showInfo.value?.text ?: "",
                        Modifier.fillMaxSize(),
                        fontFamily = caveatFamily,
                        textAlign = TextAlign.Center,
                        color = Color.Black,
                        fontSize = 25.sp
                    )
                }

//                Row(
//                    Modifier
//                        .align(Alignment.Center)
//                        .offset(x = 20.dp, y = 15.dp)
//                        .width((LocalConfiguration.current.screenWidthDp / 2.1).dp)
//                        .height((LocalConfiguration.current.screenWidthDp / 1.5).dp),
//                    Arrangement.Center,
//                    Alignment.CenterVertically
//                ) {
//                    if (home.isFirst.value)
//                        Spacer(
//                            Modifier
//                                .size(140.dp)
//                                .padding(5.dp)
//                                .offset(x = 9.dp, y = 0.dp)
//                        )
//                    else
//                        Image(
//                            painterResource(id = R.drawable.arrow_down),
//                            "",
//                            Modifier
//                                .size(120.dp)
//                                .padding(5.dp)
//                                .offset(x = 0.dp, y = 5.dp)
//                                .clickable {
//                                    home.runItems(false)
//                                },
//                            contentScale = ContentScale.Fit
//                        )
//
//                    Spacer(Modifier.weight(1f))
//
//                    if (!home.isLast.value) {
//                        Image(
//                            painterResource(id = R.drawable.arrow_up),
//                            "",
//                            Modifier
//                                .size(140.dp)
//                                .padding(5.dp)
//                                .offset(x = (-8).dp, y = (-6).dp)
//                                .clickable {
//                                    home.runItems(true)
//                                },
//                            contentScale = ContentScale.Fit
//                        )
//                    }
//                }
            }
        }

        Image(
            painterResource(id = R.drawable.feel_good_chicken),
            "",
            Modifier
                .align(Alignment.BottomEnd)
                .size(150.dp)
                .padding(5.dp)
                .offset(x = 0.dp, y = (-0).dp),
            contentScale = ContentScale.Fit
        )

        Image(
            painterResource(id = R.drawable.share_icons), "",
            Modifier
                .align(Alignment.BottomStart)
                .size(110.dp)
                .offset(x = 0.dp, y = (30).dp)
                .clickable {
                    storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                },
            contentScale = ContentScale.Fit
        )
    }


//    Box {
//        LazyColumn(
//            Modifier
//                .fillMaxSize()
//                .background(BlueColor)
//                .padding(bottom = LocalConfiguration.current.screenWidthDp.dp / 3), state = scrollState
//        ) {
//            item {
//                Image(
//                    painterResource(id = R.drawable.feel_good_text),
//                    "",
//                    Modifier
//                        .size(180.dp)
//                        .padding(5.dp)
//                        .offset(x = 0.dp, y = (-40).dp),
//                    contentScale = ContentScale.Fit
//                )
//            }
//
//            item {
//                Text(
//                    if (home.list.isNotEmpty()) stringResource(id = R.string.your_feels) else
//                        stringResource(id = R.string.no_your_feels),
//                    Modifier
//                        .fillMaxWidth()
//                        .offset(x = 0.dp, y = (-20).dp),
//                    fontFamily = caveatFamily,
//                    textAlign = TextAlign.Center,
//                    color = Color.White,
//                    fontSize = 35.sp
//                )
//            }
//
//            items(home.list) {
//                ItemsCards(it) { i ->
//                    home.showInfo(i)
//                }
//            }
//
//            if (home.doShowLoadBtn.value)
//                item {
//                    Column(
//                        Modifier.fillMaxWidth(),
//                        Arrangement.Center,
//                        Alignment.CenterHorizontally
//                    ) {
//                        Spacer(Modifier.height(60.dp))
//
//                        FilledTonalButton(onClick = { home.getPagination() }) {
//                            Text(
//                                stringResource(id = R.string.load_more),
//                                color = Color.White,
//                                fontSize = 17.sp
//                            )
//                        }
//                    }
//                }
//
//            item {
//                Column {
//                    Spacer(Modifier.height(150.dp))
//                }
//            }
//        }
//
//        Image(
//            painterResource(id = R.drawable.obb_intro),
//            "",
//            Modifier
//                .align(Alignment.BottomCenter)
//                .padding(5.dp)
//                .fillMaxWidth()
//                .height(LocalConfiguration.current.screenWidthDp.dp / 3)
//                .offset(x = 0.dp, y = 5.dp)
//                .clickable {
//                    showSplash()
//                },
//            contentScale = ContentScale.Fit
//        )
//    }


//    if (home.showInfo.value != null) InfoShowDataFull(home.showInfo.value!!)

//    BackHandler {
//        if (home.showInfo.value != null) {
//            home.showInfo(null)
//            return@BackHandler
//        }
//        activity.finish()
//    }
}


@Composable
fun InfoShowDataFull(info: ItemsListEntity) {
    Box(
        Modifier
            .fillMaxSize()
            .background(BlueColor)
            .clickable {}
    ) {
        Image(
            painterResource(id = R.drawable.info_full),
            "",
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .height(LocalConfiguration.current.screenWidthDp.dp / 2),
            contentScale = ContentScale.Fit
        )
        AsyncImage(
            File(info.imagePath),
            null,
            Modifier
                .align(Alignment.Center)
                .padding(3.dp)
                .fillMaxWidth()
                .height(LocalConfiguration.current.screenHeightDp.dp / 2),
            contentScale = ContentScale.Crop
        )

        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .offset(x = 20.dp, y = (-65).dp)
                .rotate(-10f)
                .width(LocalConfiguration.current.screenWidthDp.dp / 2 + 90.dp)
                .height(LocalConfiguration.current.screenWidthDp.dp / 2)
                .clip(RoundedCornerShape(13.dp))
                .background(Color.White)
                .verticalScroll(rememberScrollState())

        ) {
            Text(
                info.text,
                Modifier.fillMaxSize(),
                fontFamily = caveatFamily,
                textAlign = TextAlign.Center,
                color = Color.Black,
                fontSize = 25.sp
            )
        }

        Image(
            painterResource(id = R.drawable.share_feel_img), "",
            Modifier
                .align(Alignment.BottomEnd)
                .width(LocalConfiguration.current.screenWidthDp.dp / 2)
                .padding(3.dp)
                .clickable {
                    shareText(info.text, File(""))
                },
            contentScale = ContentScale.Crop
        )

    }
}

@Composable
fun ItemsCards(item: ItemsListEntity, click: (ItemsListEntity) -> Unit) {

    Row(
        Modifier
            .padding(vertical = 12.dp, horizontal = 6.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color.White)
            .padding(4.dp)
            .clickable {
                click(item)
            },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painterResource(id = R.drawable.feel_good_chicken), "",
            Modifier.size(50.dp), contentScale = ContentScale.Crop
        )

        Text(
            item.text,
            Modifier.weight(1f),
            fontFamily = juliusFamily,
            textAlign = TextAlign.Start,
            color = Color.Black,
            fontSize = 15.sp,
            maxLines = 3
        )

        AsyncImage(
            File(item.imagePath),
            null,
            Modifier
                .padding(3.dp)
                .size(90.dp),
            contentScale = ContentScale.Crop
        )
    }
}
