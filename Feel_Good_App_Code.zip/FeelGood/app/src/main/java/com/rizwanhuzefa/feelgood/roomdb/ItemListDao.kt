package com.rizwanhuzefa.feelgood.roomdb


import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.rizwanhuzefa.feelgood.utils.Utils.DB_NAME

@Dao
interface ItemListDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(users: ItemsListEntity)

    @Query("SELECT * FROM $DB_NAME ORDER BY ts DESC LIMIT :limit, 500")
    suspend fun getAll(limit: Int): List<ItemsListEntity>


    @Query("SELECT * FROM $DB_NAME ORDER BY ts DESC LIMIT 10")
    suspend fun getLatestTen(): List<ItemsListEntity>

}
