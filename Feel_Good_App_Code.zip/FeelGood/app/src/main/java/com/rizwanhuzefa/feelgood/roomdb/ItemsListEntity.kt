package com.rizwanhuzefa.feelgood.roomdb

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.rizwanhuzefa.feelgood.utils.Utils.DB_NAME

@Entity(tableName = DB_NAME)
data class ItemsListEntity(
    @PrimaryKey(true) val id: Int? = null,
    val text: String,
    val ts: Long,
    val imagePath: String
)